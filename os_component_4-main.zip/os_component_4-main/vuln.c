#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

extern char **environ;

void secretfunction() {
    printf("\n--- !!! Congratulations !!! You entered the secret function ---\n");
    char *args[] = {"bash", NULL};
    execve("/bin/bash", args, environ);
}

void echo() {
    char buf[20];
    printf("Please enter some text: ");
    fflush(stdout);
    read(0, buf, 200);
    puts("Input received");
}

int main() {
    setbuf(stdout, NULL);
    echo();
    puts("Goodbye see you");
}


